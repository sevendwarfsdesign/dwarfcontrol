# zjazz CUDA miner #

**Download link:** [https://github.com/zjazz/zjazz_cuda_miner/releases](https://github.com/zjazz/zjazz_cuda_miner/releases)

This is a Windows and Linux miner for nVidia CUDA GPUs.

Windows requires CUDA 9.1 (or higher). Linux CUDA 9.1 and CUDA 9.2 packages available.

User manual available here: https://github.com/zjazz/zjazz_cuda_miner/blob/master/MANUAL.md

### Support/Contact ###

Discord channel: https://discord.gg/FRUVSJT

### Devfee ###

2% devfee, it starts randomly.

### Algorithms / Hashrates ###

#### Cuckoo (MeritCoin) ###

Cuckoo is used to mine MeritCoin.

Check the [Merit guide](https://github.com/zjazz/zjazz_cuda_miner/blob/master/MERIT.md) for properly tuning the miner.

#### Cuckoo (BitCash)

BitCash uses a variant of Merit's cuckoo algorithm. Use command line algorithm name *bitcash* to select it.

#### X22i (SUQA)

X22i is the algorithm used by SUQA.

### Usage ###

For a complete list of options, add --help to command line arguments list.

### License ###

Use -l command line argument to print the full license (including thirdparty software licenses).

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### Donations ###

BTC: 1Fx8QDdyFJt3NWLkuKeBvsv4nNrFTNK9X7

Merit: MUkd3GdqNCCsaHmCSAeNRnAaAGi7M4v7Xo

