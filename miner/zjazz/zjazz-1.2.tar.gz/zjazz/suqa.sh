./zjazz_cuda -a x22i -o stratum+tcp://mine.icemining.ca:4200 -u  SYh56Smy42HamYhTLuLUDWTvsdP1cELD5P -p c=SUQA
