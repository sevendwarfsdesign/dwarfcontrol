#!/bin/sh
./miner --algo 192_7 --pers ZERO_PoW --server zer-eu.forgetop.com --port 2052 --user t1d1YLkZ94UhUE1G6nJLHA2Qf3HPD5JqgwQ.rig0 --pass x --pec
